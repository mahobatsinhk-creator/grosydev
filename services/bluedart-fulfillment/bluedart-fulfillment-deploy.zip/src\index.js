import { mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createServer } from 'node:http';
import { readFileSync, existsSync } from 'node:fs';

import { config, assertBlueDartConfig, assertBlueDartAuthConfig, assertShopifyConfig } from './config.js';
import { getShippingJwt, checkPincodeServiceability } from './bluedart.js';
import { testShopifyConnection, getOrder, listUnfulfilledOrdersPage } from './shopify.js';
import { summarizeOrder } from './map-order.js';
import { labelsDir } from './paths.js';
import { processOrder } from './fulfill.js';
import { processAllUnfulfilled } from './batch.js';
import { listGeneratedOrders, findGeneratedByAwb } from './generated-orders.js';
import { lookupOrder } from './order-lookup.js';
import { verifyShopifyWebhook, parseWebhookOrder, shouldAutoFulfillOrder } from './webhook.js';
import { buildLabelPrintHtml, buildPackingSlipHtml, savePackingSlip } from './packing-slip.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
mkdirSync(labelsDir, { recursive: true });

function json(res, status, body) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
}

function unauthorized(req, res) {
  if (!config.apiSecret) return false;
  const header = req.headers['x-api-secret'] || req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (header !== config.apiSecret) {
    json(res, 401, { error: 'Unauthorized' });
    return true;
  }
  return false;
}

async function readRawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

async function readJsonBody(req) {
  const raw = await readRawBody(req);
  const text = raw.toString('utf8');
  return { raw, data: text ? JSON.parse(text) : {} };
}

function serveStatic(res, filePath, contentType) {
  if (!existsSync(filePath)) {
    json(res, 404, { error: 'Not found' });
    return;
  }
  res.writeHead(200, { 'Content-Type': contentType });
  res.end(readFileSync(filePath));
}

function startAutoFulfillCron() {
  const mode = config.autoFulfillMode;
  const minutes = config.autoFulfillCronMinutes;
  if (!minutes || minutes < 1) return;
  if (mode !== 'batch' && mode !== 'all') return;

  const run = async () => {
    try {
      console.log('[auto-fulfill] Running batch…');
      const result = await processAllUnfulfilled({
        limit: config.autoFulfillBatchLimit,
        notifyCustomer: config.autoFulfillNotifyCustomer,
      });
      console.log(
        `[auto-fulfill] Done: ${result.success}/${result.processed} succeeded, ${result.failed} failed`
      );
    } catch (err) {
      console.error('[auto-fulfill] Error:', err.message || err);
    }
  };

  run();
  setInterval(run, minutes * 60 * 1000);
  console.log(`[auto-fulfill] Batch every ${minutes} minutes (mode: ${mode})`);
}

export function startServer() {
  const publicDir = resolve(__dirname, '../public');

  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url, `http://${req.headers.host}`);

      if (req.method === 'GET' && url.pathname === '/') {
        serveStatic(res, resolve(publicDir, 'index.html'), 'text/html; charset=utf-8');
        return;
      }

      if (req.method === 'GET' && url.pathname === '/health') {
        json(res, 200, {
          ok: true,
          shop: config.shopify.shop,
          autoFulfillMode: config.autoFulfillMode,
        });
        return;
      }

      // Shopify webhook — verified by HMAC, not API secret
      if (req.method === 'POST' && url.pathname === '/webhooks/shopify/orders-paid') {
        const raw = await readRawBody(req);
        const hmac = req.headers['x-shopify-hmac-sha256'];
        if (!verifyShopifyWebhook(raw.toString('utf8'), hmac)) {
          json(res, 401, { error: 'Invalid webhook signature' });
          return;
        }

        const mode = config.autoFulfillMode;
        if (mode !== 'webhook' && mode !== 'all') {
          json(res, 200, { skipped: true, reason: 'AUTO_FULFILL_MODE is not webhook/all' });
          return;
        }

        const webhookOrder = parseWebhookOrder(raw.toString('utf8'));
        if (!shouldAutoFulfillOrder(webhookOrder)) {
          json(res, 200, { skipped: true, order: webhookOrder.name });
          return;
        }

        const result = await processOrder(webhookOrder.id, {
          notifyCustomer: config.autoFulfillNotifyCustomer,
        });
        json(res, 200, result);
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/qr') {
        const data = url.searchParams.get('data') || '';
        const size = Math.min(Math.max(Number(url.searchParams.get('size')) || 128, 32), 512);
        if (!data) {
          json(res, 400, { error: 'Missing data' });
          return;
        }
        const qrRes = await fetch(
          `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=0&data=${encodeURIComponent(data)}`
        );
        if (!qrRes.ok) {
          json(res, 502, { error: 'QR generation failed' });
          return;
        }
        const buf = Buffer.from(await qrRes.arrayBuffer());
        res.writeHead(200, {
          'Content-Type': 'image/png',
          'Cache-Control': 'public, max-age=86400',
        });
        res.end(buf);
        return;
      }

      if (req.method === 'GET' && url.pathname.startsWith('/api/labels/')) {
        const awb = url.pathname.replace('/api/labels/', '').replace(/\.pdf$/i, '');
        if (!/^\d+$/.test(awb)) {
          json(res, 400, { error: 'Invalid AWB' });
          return;
        }
        const labelPath = resolve(labelsDir, `${awb}.pdf`);
        if (!existsSync(labelPath)) {
          json(res, 404, { error: 'Label not found' });
          return;
        }
        res.writeHead(200, { 'Content-Type': 'application/pdf' });
        res.end(readFileSync(labelPath));
        return;
      }

      if (
        req.method === 'GET' &&
        (url.pathname.startsWith('/api/packing-slip/') || url.pathname.startsWith('/api/packing_slip/'))
      ) {
        const awb = url.pathname
          .replace('/api/packing-slip/', '')
          .replace('/api/packing_slip/', '')
          .replace(/\.html$/i, '');
        if (!/^\d+$/.test(awb)) {
          json(res, 400, { error: 'Invalid AWB' });
          return;
        }

        let orderRef = url.searchParams.get('order');
        if (!orderRef) {
          const entry = findGeneratedByAwb(awb);
          if (entry?.orderName && entry.orderName !== '—') {
            orderRef = entry.orderName;
          }
        }

        if (orderRef) {
          assertShopifyConfig();
          const order = await getOrder(orderRef);
          savePackingSlip(order, awb);
          res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
          res.end(buildPackingSlipHtml(order, awb));
          return;
        }

        const slipPath = resolve(labelsDir, `${awb}-packing-slip.html`);
        if (existsSync(slipPath)) {
          serveStatic(res, slipPath, 'text/html; charset=utf-8');
          return;
        }
        json(res, 404, { error: 'Packing slip not found — re-fulfill order or run regenerate script' });
        return;
      }

      if (req.method === 'GET' && url.pathname.startsWith('/api/print-label/')) {
        const awb = url.pathname.replace('/api/print-label/', '');
        if (!/^\d+$/.test(awb)) {
          json(res, 400, { error: 'Invalid AWB' });
          return;
        }
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(buildLabelPrintHtml(awb));
        return;
      }

      if (unauthorized(req, res)) return;

      if (req.method === 'GET' && url.pathname === '/api/shopify/test') {
        assertShopifyConfig();
        const shop = await testShopifyConnection();
        json(res, 200, { ok: true, shop });
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/orders/unfulfilled') {
        assertShopifyConfig();
        const limit = Math.min(Number(url.searchParams.get('limit') || 25), 250);
        const pageInfo = url.searchParams.get('page_info') || '';
        const result = await listUnfulfilledOrdersPage({ limit, pageInfo });
        json(res, 200, {
          orders: result.orders.map(summarizeOrder),
          pagination: result.pagination,
        });
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/orders/generated') {
        const data = listGeneratedOrders({
          limit: Number(url.searchParams.get('limit') || 25),
          page: Number(url.searchParams.get('page') || 1),
          search: url.searchParams.get('search') || '',
        });
        json(res, 200, data);
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/orders/lookup') {
        assertShopifyConfig();
        const orderRef = url.searchParams.get('order') || url.searchParams.get('name');
        if (!orderRef) {
          json(res, 400, { error: 'order query param required (e.g. 1482 or #1482)' });
          return;
        }
        const result = await lookupOrder(orderRef);
        json(res, 200, result);
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/bluedart/test-auth') {
        assertBlueDartAuthConfig();
        const token = await getShippingJwt(true);
        json(res, 200, { ok: true, tokenLength: token.length, originArea: config.bluedart.originArea });
        return;
      }

      if (req.method === 'GET' && url.pathname === '/api/bluedart/pincode') {
        assertBlueDartAuthConfig();
        const pin = url.searchParams.get('pin');
        if (!pin) {
          json(res, 400, { error: 'pin query param required' });
          return;
        }
        const result = await checkPincodeServiceability(pin);
        json(res, 200, { pincode: pin, result });
        return;
      }

      if (req.method === 'POST' && url.pathname === '/api/fulfill/batch') {
        const { data: body } = await readJsonBody(req);
        const result = await processAllUnfulfilled({
          limit: Number(body.limit || config.autoFulfillBatchLimit),
          notifyCustomer: body.notifyCustomer !== false,
        });
        json(res, 200, result);
        return;
      }

      if (req.method === 'POST' && url.pathname === '/api/fulfill') {
        const { data: body } = await readJsonBody(req);
        const orderId = body.orderId || body.order || url.searchParams.get('order');
        if (!orderId) {
          json(res, 400, { error: 'orderId required' });
          return;
        }
        const result = await processOrder(orderId, {
          notifyCustomer: body.notifyCustomer !== false,
          dryRun: body.dryRun === true,
        });
        json(res, 200, result);
        return;
      }

      json(res, 404, { error: 'Not found' });
    } catch (err) {
      json(res, 500, { error: err.message || String(err) });
    }
  });

  server.listen(config.port, '0.0.0.0', () => {
    const local = `http://localhost:${config.port}`;
    console.log(`Grosyhub Blue Dart fulfillment: ${local}`);
    if (config.publicUrl) {
      console.log(`Live dashboard: ${config.publicUrl}`);
      console.log(`Webhook: ${config.publicUrl}/webhooks/shopify/orders-paid`);
    }
    console.log('Shiprocket checkout is unchanged — this only runs after orders are placed.');
    startAutoFulfillCron();
  });
}

export { processOrder };

function isDirectEntry() {
  if (!process.argv[1]) return false;
  const entryPaths = [
    resolve(process.argv[1]),
    resolve(process.cwd(), process.argv[1]),
  ];
  return entryPaths.some((p) => import.meta.url === pathToFileURL(p).href);
}

// Hostinger / npm start / node src/index.js / node server.js
if (isDirectEntry()) {
  startServer();
}
